PHYSICS QUEST — ANDROID APK PROJECT

This is an Android Studio project wrapper for the Physics Quest web app. It is source code, not a compiled APK.

BUILD AN APK:
1. On a computer, install Android Studio (stable version) and its Android SDK.
2. Extract this ZIP.
3. In Android Studio choose Open, then select the PhysicsQuestAndroid folder.
4. Allow Gradle sync and install Android SDK Platform 35 if prompted.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When the build finishes, choose Locate. The debug APK is usually:
   app/build/outputs/apk/debug/app-debug.apk
7. Transfer that APK to your Android phone and install it. If Android asks, allow installation from that source.

APP FEATURES:
- 14-chapter checklist
- Daily 2-hour task tracker
- 12-week roadmap
- Five-question practice quiz
- XP and completed-test counter
- Local progress saved inside app storage

NOTES:
- No internet permission is needed; the app opens its bundled HTML locally.
- Progress is stored on this app installation/device. Uninstalling or clearing app data can erase it.
- This is an unofficial study tool. Confirm current examinable topics and dates against CBSE's official syllabus.
